关于 SoftEther VPN 的重要声明

嵌入在本软件的 VPN 通信功能比以往任何时候都要强大。这个强大的 VPN 能力将为您带来巨大的好处。然而，如果你滥用此软件， IT 可能会损害你自己。为了避免这样的风险，本文档为愿意使用本软件的客户公布了重要提示。下面的说明是非常重要的。仔细阅读并理解它。


1. VPN 通信协议
1.1. SoftEther VPN 协议
SoftEther VPN 可以进行 VPN 通信。不同于传统的 VPN 协议， SoftEther VPN 有一个全新设计的 "SoftEther VPN 协议 (SE-VPN 协议)" 的实现。SE-VPN 协议将任何以太网数据包封装进 HTTPS (HTTP over SSL) 连接。因此 SE-VPN 协议可以越过防火墙通信，即使防火墙被网络管理员配置阻止传统的 VPN 数据包。SE-VPN 协议的设计和实施以符合 TLS (RFC 5246) 和 HTTPS (RFC 2818)。然面，有时对 RFC 有不同的行为。如果你是一个网络管理员，要在防火墙上阻止 SE-VPN 协议，你可以在防火墙上采取 "白名单" 策略，来过滤任何在边界上的 TCP 或 UDP 数据包，除了明确允许到特定网站和服务器的数据包。

1.2. NAT 穿透功能
一般来说，如果你使用传统的 VPN 系统，你必须要求网络管理员把 NAT 或防火墙设置为 "打开" 或 "中继" 特定的 TCP 或 UDP 端口。然而，也有需要以某种方式消除网络管理员的这种工作成本。为了满足这种需求， SoftEther VPN 有一个新实施的 "NAT 穿越" 功能。NAT 穿越默认情况下是启用的。一个在 NAT 或防火墙后面、在电脑上运行的 SoftEther VPN 服务器可以接受来自互联网的 VPN 连接，在防火墙或 NAT 上没有任何特殊的配置。如果你想禁用 NAT 穿越功能，修改 SoftEther VPN 服务器上的配置文件 "DisableNatTraversal" 为 "true" 。为了在客户端禁用它，在目标主机添加 "/ tcp" 后缀。

1.3. 动态 DNS 功能
传统的 VPN 系统在 VPN 服务器上需要一个静态全球 IP 地址。鉴于全球 IP 地址的短缺， SoftEther 公司在 SoftEther VPN 服务器上实施了 "动态 DNS 功能" 。动态 DNS 是默认启用的。动态 DNS 功能通知计算机的当前全球 IP 地址到由 SoftEther 公司操作的动态 DNS 服务器。一个全球唯一主机名 (FQDN) ，如 "abc.softether.net" ( "ABC" 随每个用户唯一而不同) 将在 VPN 服务器上被指定。如果你告诉一个 VPN 用户这个唯一的主机名，用户可以在 VPN 客户端上将其指定为目标 VPN 服务器的主机名，将能连接到 VPN 服务器。事先无需知道 IP 地址。如果 VPN 服务器的 IP 地址变化了，相关动态 DNS 服务的主机名注册的 IP 地址会自动改变。通过这种机制，不再需要每月向 ISP 缴费的全球静态 IP 地址。您可以使用带动态 IP 地址的、消费者级、廉价的互联网连接，来操作一个企业级的 VPN 系统。如果你想禁用动态 DNS ，把 SoftEther VPN 服务器配置文件中的 "DDnsClient" 指令的 "Disabled" 项目指定为 "true" 。* 中华人民共和国的居民请注意:如果你的 VPN 服务器运行在中华人民共和国， DNS 后缀将被替换为 "sedns.cn" 域名。 "sedns.cn" 域名服务由 "北京大游索易科技有限公司" 拥有和运营的，它是一个中国本地的企业。

1.4. VPN over ICMP / VPN over DNS 功能
如果你想在 SoftEther VPN 客户端 / 网桥和 SoftEther VPN 服务器之间建立一个 VPN 连接，但如果 TCP 和 UDP 数据包被防火墙禁止通过，那么你可以把有效载荷封装进 "ICMP" (被称为 Ping) 或 "DNS" 数据包。通过使用 ICMP 或 DNS ，即使防火墙或路由器阻止每个 TCP 或 UDP 连接，此功能可以实现 VPN 连接。VPN over ICMP/ VPN over DNS 功能尽可能的设计符合标准 ICMP 和 DNS 规范，但有时也不完全符合他们的行为。因此，一些劣质路由器可能会导致内存溢出或当有很多 ICMP 或 DNS 数据包通过时产生麻烦，这种路由器有时死机或重新启动。它可能会影响在同一网络上的其他用户。为了避免这样的风险，在 VPN 客户端指定的目标主机名上附加后缀 "/tcp" ，禁用 VPN over ICMP / DNS 功能。

1.5. VPN Azure 云服务
如果您的 SoftEther VPN 服务器放置在 NAT 或防火墙后面，由于某种原因，你不能使用 NAT 穿透功能、动态 DNS 功能或 VPN over ICMP/DNS 功能，您可以使用 VPN Azure Clouse 服务。 SoftEther 公司在互联网上运行 VPN Azure 云。VPN 服务器连接到 VPN Azure 云，主机名 "abc.vpnazure.net" ( "abc" 是一个唯一的主机名) 通过 VPN Azure 云可以被指定连接到 VPN 服务器。实际上，这样的一个主机名指向一个由 SoftEther 公司所操作的云服务器的全球 IP 地址。如果一个 VPN 客户端连接到一个 VPN Azure 主机，那么 VPN Azure 主机转播在 VPN 客户端和 VPN 服务器之间的所有流量。VPN Azure 在默认情况下是禁用的。您可以通过使用 VPN 服务器配置工具很容易地激活它。

1.6. UDP 加速
SoftEther VPN 具有 UDP 加速功能。如果一个 VPN 是由两个站点组成检测到 UDP 通道已建立， UDP 将自动使用。通过此功能， UDP 的吞吐量增加了。如果直接的 UDP 通道已被建立，直接的 UDP 数据包将被使用。但是，如果有一些障碍，如防火墙或 NAT ， "UDP 冲孔" 技术将被使用。 "UDP 冲孔" 使用 SoftEther 公司在互联网上操作的云服务器。UDP 加速通过在 VPN 客户端一侧进行设置在任何时候可以被禁用。


2. VPN 软件
The notes in this section are not specific to SoftEther VPN or VPN Gate, but apply to general system software. SoftEther VPN Client, SoftEther VPN Server, SoftEther VPN Bridge, and VPN Gate Relay Service will be installed on your computer as system services. System services always run in the background. System services usually do not appear on the computer display. Then your computer system is booted, system services automatically start in the background even before you or other users log in. To check whether PacketiX-related system service is running, check the process list or the background service list of your OS (called as "Services" in Windows, or "Daemons" in UNIX.) You can activate, deactivate, start, or stop system services using the functions of the OS anytime. PacketiX-related GUI tools for managing system services communicate with these system services. After you terminate these management GUI tools, PacketiX-related system services will continue to run in the background. System services consume CPU time, computer power, memory and disk space. Because system services consume power, your electricity charges and amount of thermal of your computer increase as result. In addition, there is a possibility that the mechanical parts of the life of your computer is reduced.

2.1. SoftEther VPN 客户端
如果您在 Windows 上使用 SoftEther VPN 客户端，虚拟网络适配器设备驱动程序将安装在 Windows 上。虚拟网络适配器作为一个内核模式驱动程序实施在 Windows 上。驱动程序是数字签名的，由 VeriSign ， Inc 所签发的证书，还由 Symantec Corporation (赛门铁克公司) 签署。问你要确保安装驱动程序的一条消息可能会弹出在屏幕上。如果可能的话， SoftEther VPN 客户端可能会响应消息。SoftEther VPN 客户端还优化了在 Windows 上 MMCSS (多媒体类计划程序服务) 的配置。您以后可以撤消 MMCSS 的优化。

2.2. SoftEther VPN 服务器 / 网桥
如果您使用 SoftEther VPN 服务器 / 网桥在 Windows 上的 "本地网桥" 功能，你必须在电脑上安装低级别的以太网数据包处理驱动程序。驱动程序是数字签名的，由 VeriSign ， Inc 所签发的证书，还由 Symantec Corporation (赛门铁克公司) 签署。SoftEther VPN 服务器 / 网桥在物理网络适配器本地网桥功能中可以禁用 TCP / IP 卸载特性。在 Windows Vista /2008 或更高版本， VPN 服务器可以注入一个符合 Windows 过滤平台 (WPF) 规范的数据包过滤驱动程序至内核以提供 IPsec 功能。数据包过滤驱动程序将被加载仅当启用 IPsec 功能时。一旦您启用 SoftEther VPN 服务器的 IPsec 功能， Windows 内置的 IPsec 功能将被禁用。在您禁用了 SoftEther VPN 服务器的 IPsec 功能之后，那么 Windows 内置的 IPsec 功能将复苏。为了提供本地桥功能， SoftEther VPN 服务器 / 网桥在操作系统上禁用 TCP / IP 卸载功能。

2.3. 用户模式安装
您可以在 Windows 以 "用户模式" 安装 SoftEther VPN 服务器和 SoftEther VPN 网桥。换句话说，即使你没有 Windows 系统管理员的权限，你可以作为一个普通用户安装 SoftEther VPN。用户模式安装将禁用一些功能，但其他大部分功能都能正常工作。因此，例如，雇员可以在办公室网络中的计算机上安装 SoftEther VPN 服务器端，他将能够从他家连接到服务器。为了由用户自己实现这样的系统，在技术观点上无须系统管理员权限。然而，违反公司规定未经授权在计算机上安装软件可能会被视为不受欢迎的行为。如果你是一名雇员属于该公司，该公司的政策禁止安装软件或未经允许进行互联网通信，你必须事先从网络管理员或您公司的总裁获得许可，再安装 SoftEther VPN。如果您以用户模式安装 VPN 服务器 / 网桥，图标将出现在 Windows 任务托盘。如果您觉得该图标妨碍你了，你可以操作将其隐藏。然而，你不能利用此隐藏功能在其他人的电脑上安装 VPN 服务器作为间谍软件。这种行为可能是违反刑法的犯罪。

2.4. 保持活跃功能
默认情况下， SoftEther VPN 服务器和 SoftEther VPN 网桥有保持活跃的功能。此功能的目的是为了维持互连网线路的活跃。该功能定期发送带有随机 - 字节 - 数组 - 有效载荷的 UDP 数据包。此功能为避免移动或拨号连接的自动断开是非常有用的。您可以随时禁用保持活跃功能。

2.5. 卸载
SoftEther VPN 软件的卸载过程将删除所有程序文件。然而，非程序文件 (如程序运行所产生的文件和数据) 将不会被删除。由于技术原因，卸载程序的 exe 和资源文件可能仍然存在。这些剩余的文件决不会影响使用计算机，但是你可以手动删除它。内核模式驱动程序可能不会被删除，但是这样的驱动程序在 Windows 下次启动时不会被加载。您可以使用 Windows 的 "sc" 命令手动删除内核模式驱动程序。

2.6. 安全
你应该在安装后在 SoftEther VPN 服务器 / 网桥设置管理员的密码。如果你没有做到这一点，其他人未经您许可可以访问 SoftEther VPN 服务器 / 网桥，并可以设置密码。这个警告可能也适用于 Linux 版本的 SoftEther VPN 客户端。

2.7. 自动更新通知
Windows 版的 SoftEther VPN 软件有自动更新通知功能。它定期访问 SoftEther 更新服务器检查是否发布了最新版本的软件。如果最新版已发布，通知消息将在屏幕上弹出。为了达到这个目的，版本、语言设置、您的计算机的 IP 地址、唯一标识符、连接到 VPN 服务器的主机名将被发送到 SoftEther 的更新服务器。任何个人信息将不被发送。默认情况下自动更新通知是启用的，然而你可以在配置屏幕上禁用它。通过 VPN 服务器管理器，设置是否打开或关闭将被单独保存对应每个目标 VPN 服务器。

2.8. 虚拟 NAT 功能
虚拟 HUB 在 SoftEther VPN 服务器 / 网桥上有 "虚拟 NAT 功能" 。虚拟 NAT 功能可以通过 VPN 客户端的多个私有 IP 地址共享同一个物理网络上的单一 IP 地址。有两种虚拟 NAT 的操作模式:用户模式和内核模式。在用户模式下运行，虚拟 NAT 共享主操作系统上分配的一个 IP 地址。不同于用户模式，内核模式的操作试图找到物理网络上的 DHCP 服务器。如果有两个或以上的物理网络，每个网段上的 DHCP 服务器会被自动连续寻找。如果发现 DHCP 服务器，并获取一个 IP 地址， IP 地址将被虚拟 NAT 使用。在这种情况下，作为 DHCP 客户端的 IP 条目将被登记在物理 DHCP 服务器的 IP 池。为了在互连网中和主机进行通信，物理默认网关和 DNS 服务器将被虚拟 NAT 使用。在内核模式的操作中，虚拟 HUB 上有一个运行在物理以太网段上的虚拟 MAC 地址。
为了检查到互联网的连通性， SoftEther VPN 定期发送 DNS 查询数据包，以解析 "www.yahoo.com" 或 "www.baidu.com" 主机的 IP 地址，并尝试连接到这样结果 IP 地址的 TCP 80 端口，进行连通性检查。

2.9. 内核模式组件的无人值守安装
当 SoftEther VPN 检测到需要在 Windows 安装内核模式组件， Windows 系统将出现一条确认消息。在此之际， SoftEther VPN 软件将切换到无人值守的安装模式，以回应 "是" 到 Windows。当从遥远地点进行远程管理时，这个解决方案可以防止锁死。

2.10. Windows 防火墙
SoftEther VPN 软件将其自身注册为一个安全程序。这样的条目在卸载后仍被保留。您可以从 Windows 的控制面板中手动删除它。


3. 互连网服务
3.1. SoftEther 公司提供的互连网服务
SoftEther 公司在互联网上提供了动态 DNS、NAT 穿透、和 VPN Azure 服务器服务。这些服务都是免费的。客户通过使用 SoftEther VPN 软件，经由互联网访问这些服务。这些服务计划将在以后发布的 "SoftEther VPN" 的开源版本中也提供。

3.2. 发送的信息和隐私保护
为了使用上述服务， SoftEther VPN 软件可以从客户的计算机到由 SoftEther 公司操作的云服务发送 IP 地址、主机名、VPN 软件的版本。这些信息的发送是要使用这些服务的最少必须内容。无任何个人信息将被发送。 SoftEther 公司记录接收到的最少信息在云服务服务器的日志文件为 90 天。这些日志将被用于故障排除和其他合法活动。SoftEther 公司可以提供日志给属于法院、警察局和检察院的日本政府的公务人员，以遵守当局的命令。(每一个日本公务人员有责任根据法律密切保存这些信息。) 此外， IP 地址或其他信息将进行统计处理，并提供给公众，而不是暴露每一个具体的 IP 地址，以进行研究活动的发布。

3.3. 通过 VPN Azure 服务的通信数据
不管以上 3.2 的规则，如果客户使用 VPN Azure 云服务的发送或接收 VPN 数据包，实际的有效载荷将在很短的时间通过服务器的易失性存储器存储和转发。这样的行为自然需要提供 "VPN 中继服务" 。无有效载荷将被记录在 "固定的" 储存设备，如硬盘驱动器。然而， "窃听罪犯程序法" (日本在 1999 年 8 月 18 日裁决的第 137 个立法) 要求电信公司允许日本政府当局进行在线窃听。物理放置在日本的 VPN Azure 服务器也是服从于这个法律。

3.4. 符合日本电信法
SoftEther 公司符合日本电信法必要时通过互联网提供在线服务。

3.5. 免费和学术实验服务
SoftEther 作为学术实验服务提供动态 DNS、NAT 穿透和 VPN Azure。因此，服务可以被用于免费。这些服务不是 "SoftEther VPN 软件产品" 的一部分。这些服务不提供任何保证。这些服务由于技术或操作问题可能会被暂停或终止。在这种情况下，用户将无法使用这些服务。用户必须了解这些风险，并承认由用户自行承担这样的风险。SoftEther 永远不会对结果、或使用的损害、或服务无法使用承担任何责任。即使用户已经支付 SoftEther VPN 商业版的许可费用，因为支付的费用不包含这些服务的任何费用。因此，如果在线服务将停止或终止， SoftEther 公司将不提供任何退款或损害的补偿。

3.6. DNS 代理云服务器
在某些地区，当用户使用互连网，通过 ISP 线路时，一个 DNS 查询有时损坏或丢失。如果 SoftEther VPN 的服务器、客户端或网桥检测到访问实际的 VPN 服务器可能不稳定的可能性，那么 DNS 查询将被转移到由 SoftEther 公司运行的 DNS 代理云服务器。DNS 代理云服务器将回答纠正一个 IP 地址响应 DNS 查询。


4. 一般注意事项
4.1. 需要网络管理员的批准
SoftEther VPN 具有强大的功能，不需要网络管理员的特殊设置。例如，您不必要求管理员配置现有的防火墙以 "打开" TCP / UDP 端口。这些性能特点是为了以下目的:消除网络管理员的工作时间和成本，并避免误配置风险，如在防火墙上打开特定的异常端口的任务。然而，在安装 SoftEther VPN 前，属于公司的任何员工必须获得网络管理员的批准。如果您的网络管理员忽略提供这样的批准，你可以考虑获得上级领导的批准。(例如，该公司总裁。) 如果您没有获得公司领导的批准使用 SoftEther VPN ，你可能有不利的条件。SoftEther 公司将不会对使用 SoftEther VPN 的结果或损害承担责任。

4.2. 遵守贵国的法律
如果您所在国家的法律禁止加密的使用，你自己必须禁用 SoftEther VPN 的加密功能。同样，在一些国家或地区， SoftEther VPN 的某些功能可能会被法律禁止使用。其他国家的法律与 SoftEther 公司无关，因为 SoftEther 公司是一个在物理上位于并注册于日本的企业。例如，可能存在一种风险，即 SoftEther VPN 的一部分与只在某些特定区域有效的现有专利冲突。SoftEther 公司没有在日本固有领土之外这些特定区域的利益。因此，如果你想在日本以外的地区使用 SoftEther VPN ，你必须要小心不要侵犯第三人的权利。在您在这样的地区实际使用之前，您必须验证在这些特定区域使用 SoftEther VPN 的合法性。本来，在世界上有近 200 个国家，每个国家的法律都是不同的。这几乎是不可能的事先验证每一个国家的法律和法规，使软件符合所有国家的法律，再发布软件。因此 SoftEther 公司已核实 SoftEther VPN 仅对日本法律和法规的合法性。如果用户在一个特定的国家使用 SoftEther VPN ， SoftEther 公司将不会赔偿政府当局的损害，也不会承担恢复或赔偿此类损害或刑事法律责任。


5. VPN Gate 学术实验项目
(本章仅适用于 SoftEther VPN 软件包，其中包含 VPN Gate 学术实验项目的扩展插件。)
5.1. 关于 VPN Gate 学术实验项目
VPN Gate 学术实验项目是一个在线服务，由日本筑波大学研究生院为学术研究目的运营。本研究的目的是要扩大我们对 "全球分布式公共 VPN 中继服务器" 技术 (Global Distributed Public VPN Relay Server, GDPVRS) 的认识。有关详细信息，请访问 http://www.vpngate.net/。

5.2. 关于 VPN Gate 服务
SoftEther VPN 服务器和 SoftEther VPN 客户端可能含有 "VPN Gate 服务" 程序。然而， VPN Gate 服务在默认情况下是禁用的。
VPN Gate 服务通过安装了 SoftEther VPN 服务器或 SoftEther VPN 客户端的计算机所有者的志愿目的被激活并启用。在您激活 VPN Gate 服务以后，计算机将作为全球分布式公共 VPN 中继服务器的一部分开始服务。计算机的 IP 地址、主机名和相关信息将被发送并在 VPN Gate 学术实验项目的服务器目录注册，这些信息将被公布，并向公众披露。这一机制将允许任何 VPN Gate 客户端软件的用户连接到您计算机上运行的 VPN Gate 服务。当在 VPN Gate 客户端和你的 VPN Gate 服务之间建立一个 VPN 会话， VPN Gate 客户端的用户可以发送 / 接收向互联网经由 VPN Gate 服务的任何 IP 数据包。VPN Gate 服务的主机的全球 IP 地址将作为 VPN Gate 客户端启动的这种通信的源 IP 地址被使用。
VPN Gate 服务将发送一些信息至 VPN Gate 学术实验服务目录服务器。这些信息包括第 5.5 节中描述的运营商的信息、日志设置、正常运行时间、操作系统版本、协议类型、端口号、质量信息、统计信息、VPN Gate 客户端的日志历史数据 (包括日期，IP 地址，版本号和 ID) 、VPN Gate 通信的目标 HTTP/HTTPS 主机名或 IP 地址和端口号的日志记录和软件的版本。此信息可能会在目录中披露。VPN Gate 服务从目录服务器接收到一个密钥以进行在 5.9 章中描述的编码。

5.3. VPN Gate 服务行为的详细信息
如果您手动启用 VPN Gate 服务，在默认情况下是禁用的， "VPNGATE" 虚拟 Hub 将在 SoftEther VPN 服务器上被创建。如果您使用的是 SoftEther VPN 客户端，并尝试激活 VPN Gate 服务，相当于 SoftEther VPN 服务器的程序在 SoftEther VPN 客户端的同一进程将被调用，虚拟 HUB "VPNGATE" 将被创建。虚拟 HUB "VPNGATE" 包含一个默认情况下名为 "VPN" 的用户，此用户允许在互联网上的任何人建立 VPN 连接到虚拟 HUB。一旦 VPN 客户端连接到虚拟 HUB "VPNGATE" ，用户与互联网之间的任何通信将穿过虚拟 Hub ，使用运行有 SoftEther VPN 服务器 (或 SoftEther VPN 客户端) 的计算机上的物理网络接口发送 / 接收。这将导致以下结果，目标主机通过 VPN 客户端确定通信的源发起是从 VPN Gate 服务的主机的 IP 地址指定的。不过，为了安全，目的地是在 192.168.0.0/255.255.0.0 ， 172.16.0.0/255.240.0.0 或 10.0.0.0/255.0.0.0 以内的任何数据包将被虚拟 HUB "VPNGATE" 拦截，以保护您的本地网络。Any packets which destinations are within 169.254.0.0/16, 224.0.0.0/4 or 100.64.0.0/10 will also be blocked for just in case. These packet filters except DNS, ICMP and ARP packets. 因此，如果在您的企业网络或私人网络运行 VPN Gate 服务，这是安全的，因为匿名 VPN 客户端用户将不被允许访问这些私人网络。VPN Gate 服务也可作为中继访问 VPN Gate 目录服务器。
为了使 VPN Gate 服务熟悉防火墙和 NAT ，通过使用 1.2 章描述的 NAT 穿透功能打开一个 UDP 端口。还打开了一些 TCP 端口并监听，一些 TCP 和 UDP 端口将被指定为本地路由器要求的通用即插即用 (UPnP) 传输条目的目标端口。UPnP 请求数据包将被定期发送。有些路由器在设备上永久保持一个开放的 TCP/UDP 端口。如果你想关闭他们，可以手动关闭。
VPN Gate 服务还提供了镜像网站功能 www.vpngate.net。这是一种机制，将的最新内容 www.vpngate.net 的副本被托管的镜像站点微小的 HTTP 服务器上运行的 VPN Gate 服务程序。它都将自己注册上镜的站点列表中 www.vpngate.net。然而，它从来不向 www.vpngate.net 任何其他通讯中继。

5.4. 互联网之间经由 VPN Gate 服务的通信
VPN Gate 服务提供了一个用户与互联网之间的路由，通过使用 2.8 章虚拟 NAT 功能。VPN Gate 服务发送 Ping 查询数据包到位于筑波大学的服务器，和被确定为 8.8.8.8 的谷歌公共 DNS 服务器，以检查您的互联网线路的最新质量。VPN Gate 服务还发送和接收大量的随机数据包到 / 从筑波大学的速度测试服务器上。这些高质量的数据将自动地、定期地被报告给 VPN Gate 目录服务器。结果将被保存并向公众披露。这些定期的查询通信被调整，尽量不占用互联网线路，但在某些情况下可能会占用线路。

5.5. VPN Gate 服务的运营商信息
如果您激活您计算机上的 VPN Gate 服务，此计算机将成为全球分布式公共 VPN 中继服务器的一部分。因此，您的 VPN Gate 服务的运营商管理信息应被报告和注册到 VPN Gate 服务目录里。运营商的信息包含了运营商的名称、滥用报告、联系的 e-mail 地址。这些信息可以被输入到屏幕上的 VPN Gate 配置里。输入的信息将被发送到 VPN Gate 目录服务器，保存并向公众披露。所以，你必须要小心地输入信息。顺便说一下，直到你指定某名称作为运营商的信息，计算机的主机名会被自动使用作为运营商名称的字段，通过在主机名后附加 "'s owner" 字符串。

5.6. 遵守法律运营 VPN Gate 服务
在某些国家或地区，正打算激活和运行 VPN Gate 服务的用户，他被强制要求从 / 到政府获得许可或注册服务。如果您所在的地区有这样的规定，你必须在激活 VPN Gate 服务之前，提前完成强制流程。无论是 VPN Gate 学术实验项目的开发者和运营商对于发生的未能遵守当地法律的法律 / 刑事责任或损害都不承担任何责任。

5.7. 保护通信的隐私
大多数国家有一个法律要求通信服务的运营商，包括 VPN Gate 服务运营商，以保障第三方的通信隐私。当您运营 VPN Gate 服务时，你必须始终保护用户的隐私。

5.8. 数据包日志
数据包日志功能在 VPN Gate 服务上实施。它记录通过虚拟 HUB 传输的主要 TCP/IP 数据包的基本包头。此功能将有助于了解连接您的 VPN Gate 服务用户的通信发起者的 "原始 IP 地址" ，通过检查数据包日志和连接日志。数据包日志记录的仅为合法调查的目的。不会偷看，也不会泄漏数据包日志，除非正当的目的。这种行为将违反 5.7 章。

5.9. 数据包日志的自动存档和编码功能
VPN Gate 学术实验服务是根据日本宪法和法律运营和运行的。日本宪法法律要求严格保护通信的隐私权。由于这项服务是根据日本的规则， VPN Gate 服务的程序实现了此 "自动日志文件编码" 的保护机制，并默认启用。
默认情况下， VPN Gate 服务当前自动配置编码已经过去了两周或以上的数据包日志文件。为了保护通信隐私，如果一个数据包日志文件一旦被编码，即使是本地计算机管理员也无法检查数据包日志文件。这种机制保护 VPN Gate 服务最终用户的隐私。
您可以更改 VPN Gate 服务的设置，禁用此项自动编码功能。然后数据包日志文件将永远不会被编码，即使两个星期已过去。在这样的配置中，所有数据包日志将以纯文本形式保留在磁盘上。因此，你必须要注意不要侵犯用户的隐私。
如果你负责解码已编码的数据包日志文件 (例如:一个 VPN Gate 服务的用户非法滥用你的 VPN Gate 服务，你必须解码数据包日志以符合法律) ，请联系日本筑波大学研究生院 VPN Gate 学术实验服务的管理员。你可以从 http://www.vpngate.net/ 找到联系地址。根据法律如果有从法院或其他司法当局适当的和法律的要求， VPN Gate 服务的管理员将响应解码数据包日志。
根据技术或管理原因，可能会禁用 "数据包日志自动存档和编码" 功能。

5.10. 在日本领土操作 VPN Gate 服务的注意事项
当一个用户在日本领土操作 VPN Gate 服务时，这种行为会根据日本电信法加以规范，操作受法律管辖。然而，在这样的情况下，根据 "日本电信业务竞争手册 [补充版本]" ，非营利性的通信业务不被认为是 "电信业务" 。因此，通常 VPN Gate 服务的运营商不受制于 "电信业务经营者" ，不强制要求到政府注册。

5.11. VPN Gate 客户端
如果 SoftEther VPN 客户端包含 VPN Gate 客户端插件，你可以在互联网上用它来获得当前操作的 VPN Gate 服务的服务器列表，使一个 VPN 连接到列表上的特定服务器。
VPN Gate 客户端始终定期保持 VPN Gate 服务的最新列表。要小心，如果你使用的是按使用量付费的互联网线路。
当您启动 VPN Gate 客户端软件，要求你激活或不是 VPN Gate 服务的屏幕将出现。VPN Gate 服务的详细信息，请阅读上述各节。

5.12. 在加入或使用 VPN Gate 学术实验项目之前的注意事项
VPN Gate 学术实验服务是作为日本筑波大学研究生院的一个研究项目运营的。该服务受日本法律管理。其他国家的法律不受我们关注也不承担责任。
从本质上讲，在世界上有近 200 个国家，都有不同的法律。不可能在软件发布前去验证每一个国家的法律和法规，并使我们的软件符合所有国家的法律。如果用户在一个特定的国家使用 VPN Gate 服务，损坏公务人员的权力，服务或软件的开发者将永远不会负责恢复或补偿等损害或刑事责任。
通过使用本软件和服务，用户有自己的义务必须遵守所有相关的法律和规则。用户将完全承担任何损失和使用本软件及服务导致的责任，无论日本领土以内还是以外。
如果你不同意也不理解上述警告，不要使用任何 VPN Gate 学术实验服务功能。
VPN Gate 仅仅是学术目的的一个研究项目。VPN Gate 是作为 SoftEtherVPN 和 UT-VPN 的一个插件被开发的。然而， VPN Gate 的每一部分都是在筑波大学的这一研究项目被开发的。VPN Gate 的任何部分都不是 SoftEther 公司开发的。VPN Gate 研究项目不是由 SoftEther 公司引导、经营，推广和保证的。

5.13. VPN Gate 客户端的 P2P 中继功能可加强针对防火墙管控的规避能力
P2P 中继功能是为了加强规避防火墙管控的能力。如果 P2P 中继功能在您的 VPN Gate 客户端被启用，那么 P2P 中继功能将接受来自 VPN Gate 用户的 VPN 连接，提供中继功能给外部远程 VPN Gate 的服务器，这是由第三方在免费的互联网环境下托管的。此 P2P 中继功能从来不提供共享 NAT 功能，也不更换 VPN Gate 用户的传出 IP 地址为你的 IP 地址，因为这个 P2P 中继功能只提供 "反射服务" (发夹中继) ，从进入的 VPN Gate 用户中继到一个外部的 VPN Gate 服务器。在这种情况下，经由您的 P2P 中继功能的 VPN 隧道将终止于外部的 VPN Gate 服务器，而不是你的 VPN Gate 客户端。然而， VPN Gate 服务器作为最终目的地将记录您的 IP 地址作为通过您的 P2P 中继功能发起的 VPN 隧道的源 IP 地址。此外，经由你的 P2P 中继功能传输的用户数据包将被记录在您的计算机的数据包日志上，如 5.8 章所述。当您安装了 VPN Gate 客户端之后，如果将 P2P 中继功能设置为自动启用，那么在 5.2，5.3，5.4，5.5，5.6，5.7，5.8，5.9，5.10，5.11 和 5.12 章节中的所有事项将被应用于你的电脑，与您启用 VPN Gate 服务 (VPN Gate 服务器功能) 时的情况相同。如果你的 P2P 功能被启用，那么在第 5.5 章节中描述的您的计算机 IP 地址和默认运营商名字将被列在由 VPN Gate 项目提供的 VPN Gate 服务器列表上。您可以通过手动编辑 "vpn_gate_relay.config" 文件更改这些字符串。需要注意的是，在编辑之前您需要停止 VPN 客户端服务。如果 VPN Gate 客户端检测到您的计算机位于存在审查制度的防火墙区域， VPN 客户端会自动启用您的计算机上的 P2P 中继功能。如果您希望禁用 P2P 中继功能，您必须在 VPN 客户端的配置文件 "vpn_client.config" 上设置 "DisableRelayServer" 标志为 "true" 。需要注意的是，编辑它之前您需要停止 VPN 客户端服务。即使您的国家或地区有法律限制运行 P2P 中继功能， VPN Gate 客户端仍会激活 P2P 中继功能。如果您身处于存在这些法律限制的区域，请您遵守相关法律法规，通过设置 "DisableRelayServer" 标志手动禁用 VPN Gate 客户端的 P2P 中继功能。

SoftEther VPN and VPN Gate (where applicable) are provided, distributed and operated under the responsibility of SoftEther Corporation (Corporate Number: 1050001016519, Tsukuba, Ibaraki, Japan). These projects were researched and developed in collaboration with Tsukuba University, a national university in Japan.

THIS SOFTWARE IS DEVELOPED IN JAPAN, AND DISTRIBUTED FROM JAPAN, UNDER JAPANESE LAWS. YOU MUST AGREE IN ADVANCE TO USE, COPY, MODIFY, MERGE, PUBLISH, DISTRIBUTE, SUBLICENSE, AND/OR SELL COPIES OF THIS SOFTWARE, THAT ANY JURIDICAL DISPUTES WHICH ARE CONCERNED TO THIS SOFTWARE OR ITS CONTENTS, AGAINST US (SOFTETHER CORPORATION OR OTHER SUPPLIERS), OR ANY JURIDICAL DISPUTES AGAINST US WHICH ARE CAUSED BY ANY KIND OF USING, COPYING, MODIFYING, MERGING, PUBLISHING, DISTRIBUTING, SUBLICENSING, AND/OR SELLING COPIES OF THIS SOFTWARE SHALL BE REGARDED AS BE CONSTRUED AND CONTROLLED BY JAPANESE LAWS, AND YOU MUST FURTHER CONSENT TO EXCLUSIVE JURISDICTION AND VENUE IN THE COURTS SITTING IN TOKYO, JAPAN. YOU MUST WAIVE ALL DEFENSES OF LACK OF PERSONAL JURISDICTION AND FORUM NON CONVENIENS. PROCESS MAY BE SERVED ON EITHER PARTY IN THE MANNER AUTHORIZED BY APPLICABLE LAW OR COURT RULE.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE SUPPLIERS, PROVIDERS, OPERATORS, AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

IMPORTANT NOTE: USE OF THIS SOFTWARE AND SERVICE BY INDIVIDUALS TO WHOM THE CONSUMER CONTRACT ACT APPLIES IS NOT ALLOWED. THIS SOFTWARE IS INTENDED FOR PROFESSIONALS AND IS NOT DESIGNED FOR PURELY BUSINESS-UNRELATED CONSUMERS. THIS SOFTWARE AND SERVICE MAY BE USED ONLY FOR BUSINESS, COMMERCIAL, NON-PROFIT, ORGANIZATIONAL OPERATIONS, RESEARCH AND DEVELOPMENT PURPOSES OR OTHER NON-CONSUMPTIVE PURPOSES. THIS SOFTWARE IS NOT INTENDED FOR USE BY CONSUMERS. THIS SOFTWARE MAY NOT BE USED BY ANY INDIVIDUAL TO WHOM THE CONSUMER RIGHTS PROTECTIONS IN THE CONSUMER CONTRACT ACT OF JAPAN OR EQUIVALENT LAWS OF OTHER COUNTRIES APPLY. IF AN INDIVIDUAL USES THE SOFTWARE, THE USE OF THE SOFTWARE SHALL BE DEEMED TO BE FOR BUSINESS PURPOSES.

